﻿using System;
using System.Data;

namespace HotelReservation
{
    class Program
    {
        public const int _noOfDays = 365;
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to ABC Hotel\n");

            string roomSize;
            try
            {
            CASE1:
                Console.WriteLine("Enter Room size");
                roomSize = Console.ReadLine();
                if (!roomSize.IsInputNumber())
                {
                    Console.WriteLine("Enter a valid room size number");
                    goto CASE1;
                }
                DataTable roomDataTable = HotelBookings.GetRoomData(Convert.ToInt32(roomSize), _noOfDays);

            CASE2:
                string checkinDate;
                string checkoutDate;
                Console.WriteLine("\nEnter CheckIn Date:");
                checkinDate = Console.ReadLine();
                Console.WriteLine("Enter CheckOut Date:");
                checkoutDate = Console.ReadLine();
                if (!checkinDate.IsInputNumber())
                {
                    Console.WriteLine("Enter a valid CheckIn number");
                    goto CASE2;
                }
                if (!checkoutDate.IsInputNumber())
                {
                    Console.WriteLine("Enter a valid CheckOut number");
                    goto CASE2;
                }

                string bookingResult = HotelBookings.GetRoomAvailabilityStatus(Convert.ToInt32(roomSize), Convert.ToInt32(checkinDate), Convert.ToInt32(checkoutDate), roomDataTable, _noOfDays);
                Console.WriteLine(bookingResult);
                goto CASE2;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something went wrong. Not able to book due to:- " + ex.Message.ToString());
                Console.ReadLine();
            }
        }
    }

    public class HotelBookings
    {
        public static string GetRoomAvailabilityStatus(int roomSize, int checkinIndex, int checkoutIndex, DataTable resourceAvailable, int maxDays)
        {
            string result = "";
            if (checkinIndex > checkoutIndex)
            {
                return "End Data is grater then StartDate";
            }
            if (roomSize > 1000 || roomSize < 1)
            {
                return "RoomSize is out of range";
            }
            if (checkinIndex < 0 || checkoutIndex < 0 || checkoutIndex > maxDays || checkinIndex > maxDays)
            {
                return "Decline";
            }
            int roomno = GetRoomNo(checkinIndex, checkoutIndex, resourceAvailable);
            if (roomno > 0)
            {
                UpdateReservationData(roomno, checkinIndex, checkoutIndex, resourceAvailable);
                result = "Accept";
            }
            else
            {
                result = "Decline";
            }
            return result;
        }
        private static void UpdateReservationData(int roomNo, int checkinIndex, int checkoutIndex, DataTable source)
        {
            for (int j = checkinIndex; j <= checkoutIndex; j++)
            {
                source.Rows[roomNo - 1]["Day" + j] = true;
            }
            source.AcceptChanges();
        }
        private static int GetRoomNo(int checkinIndex, int checkoutIndex, DataTable source)
        {
            bool found = false;
            int roomno = 0;
            int recentlyBooked = 0;
            foreach (DataRowView item in source.DefaultView)
            {
                for (int j = checkinIndex; j <= checkoutIndex; j++)
                {
                    found = true;
                    if ((bool)item["Day" + j])
                    {
                        found = false;
                        j = checkoutIndex + 1;
                    }
                }
                if (found)
                {
                    //calculate closest booking from previous date

                    int closetPosition = 0;
                    for (int j = checkinIndex - 1; j >= 0; j--)
                    {
                        if ((bool)item["Day" + j])
                        {
                            closetPosition = j;
                            j = -1;
                        }
                    }
                    if ((checkinIndex - closetPosition) == 1)
                    {
                        return (int)item.Row["RoomNo"];
                    }
                    else if ((checkinIndex - closetPosition) <= (checkinIndex - recentlyBooked))
                    {
                        recentlyBooked = closetPosition;
                        roomno = (int)item.Row["RoomNo"];
                    }
                }
            }
            return roomno;
        }
        public static DataTable GetRoomData(int noOfRoom, int noOfDays)
        {
            DataTable table = new DataTable();
            for (int i = 0; i < noOfDays; i++)
            {
                DataColumn objDataColumn = new DataColumn
                {
                    DataType = typeof(bool),
                    DefaultValue = false,
                    ColumnName = "Day" + i
                };
                table.Columns.Add(objDataColumn);
            }
            DataColumn objDataColumnRoom = new DataColumn
            {
                DataType = typeof(int),
                ColumnName = "RoomNo"
            };
            table.Columns.Add(objDataColumnRoom);
            for (int i = 0; i < noOfRoom; i++)
            {
                DataRow workRow = table.NewRow();
                workRow["RoomNo"] = i + 1;
                table.Rows.Add(workRow);
            }
            table.AcceptChanges();
            return table;
        }

    }

    public static class CommanHelper
    {
        public static bool IsInputNumber(this string input)
        {
            int.TryParse(input, out int output);
            return output < 0 ? false : true;
        }
    }
}
