﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using HotelReservation;
using System.Data;
using System.Collections.Generic;

namespace HotelBookingTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Room Size:1
            DataTable roomDataTable = HotelBookings.GetRoomData(1, 365);
            List<Tuple<int, int, string>> list = new List<Tuple<int, int, string>>();
            List<Tuple<int, int, string>> lstTuples = list;
            lstTuples.Add(new Tuple<int, int, string>(-4, 2, "Decline"));
            lstTuples.Add(new Tuple<int, int, string>(200, 400, "Decline"));

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(1, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }

        }

        [TestMethod]
        public void TestMethod2()
        {
            //Room Size:3
            DataTable roomDataTable = HotelBookings.GetRoomData(3, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(0, 5, "Accept"),
                new Tuple<int, int, string>(7, 13, "Accept"),
                new Tuple<int, int, string>(3, 9, "Accept"),
                new Tuple<int, int, string>(5, 7, "Accept"),
                new Tuple<int, int, string>(6, 6, "Accept"),
                new Tuple<int, int, string>(0, 4, "Accept")
            };


            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(3, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }

        }
        [TestMethod]
        public void TestMethod3()
        {
            //Room Size:3
            DataTable roomDataTable = HotelBookings.GetRoomData(3, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(1, 3, "Accept"),
                new Tuple<int, int, string>(2, 5, "Accept"),
                new Tuple<int, int, string>(1, 9, "Accept"),
                new Tuple<int, int, string>(0, 15, "Decline")
            };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(3, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }
        }

        [TestMethod]
        public void TestMethod4()
        {
            //Room Size:3
            DataTable roomDataTable = HotelBookings.GetRoomData(3, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(1, 3, "Accept"),
                new Tuple<int, int, string>(0, 15, "Accept"),
                new Tuple<int, int, string>(1, 9, "Accept"),
                new Tuple<int, int, string>(2, 5, "Decline"),
                new Tuple<int, int, string>(4, 9, "Accept")
            };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(3, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }

        }
        [TestMethod]
        public void TestMethod5()
        {
            //Room Size:2
            DataTable roomDataTable = HotelBookings.GetRoomData(2, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(1, 3, "Accept"),
                new Tuple<int, int, string>(0, 4, "Accept"),
                new Tuple<int, int, string>(2, 3, "Decline"),
                new Tuple<int, int, string>(5, 5, "Accept"),
                new Tuple<int, int, string>(4, 10, "Accept"),
                new Tuple<int, int, string>(10, 10, "Accept"),
                new Tuple<int, int, string>(6, 7, "Accept"),
                new Tuple<int, int, string>(8, 10, "Decline"),
                new Tuple<int, int, string>(8, 9, "Accept")
            };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(2, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }
        }
        [TestMethod]
        public void TestMethod6()
        {
            //Room Size:1000
            DataTable roomDataTable = HotelBookings.GetRoomData(1000, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept"),
                new Tuple<int, int, string>(0, 6, "Accept")
            };



            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(1000, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }
        }
        [TestMethod]
        public void TestMethod7()
        {
            //Room Size:1000
            DataTable roomDataTable = HotelBookings.GetRoomData(1000, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept"),
                new Tuple<int, int, string>(0, 2, "Accept")
            };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(1000, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }
        }

        [TestMethod]
        public void TestMethod8()
        {
            //Room Size:2
            DataTable roomDataTable = HotelBookings.GetRoomData(2, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                new Tuple<int, int, string>(0, 0, "Accept"),
                new Tuple<int, int, string>(0, 1, "Accept"),
                new Tuple<int, int, string>(5, 5, "Accept"),
                new Tuple<int, int, string>(4, 5, "Accept"),
                new Tuple<int, int, string>(3, 3, "Accept"),
                new Tuple<int, int, string>(1, 3, "Accept")
           
        };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(2, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }

        }
        [TestMethod]
        public void TestMethod9()
        {
            //Room Size:2
            DataTable roomDataTable = HotelBookings.GetRoomData(2, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>
            {
                
                new Tuple<int, int, string>(0, 0, "Accept"),
                new Tuple<int, int, string>(0, 1, "Accept"),
                new Tuple<int, int, string>(5, 5, "Accept"),
                new Tuple<int, int, string>(4, 5, "Accept"),
                new Tuple<int, int, string>(3, 3, "Accept"),
                new Tuple<int, int, string>(2, 4, "Decline")
           
        };

            foreach (var bookReq in lstTuples)
            {
                string bookResult = HotelBookings.GetRoomAvailabilityStatus(2, bookReq.Item1, bookReq.Item2, roomDataTable, 365);
                Assert.AreEqual(bookReq.Item3, bookResult);
            }

        }
    }

}